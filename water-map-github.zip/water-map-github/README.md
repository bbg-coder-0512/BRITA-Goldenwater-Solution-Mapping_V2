# 中国水质方案匹配地图

这是一个可直接部署到 GitHub Pages 的静态交互式地图项目。

## 文件说明

- `index.html`：网页入口
- `css/style.css`：页面样式
- `js/app.js`：地图交互逻辑
- `data/water-data.js`：由完整方案匹配表导出的数据，共 338 条区域记录

## 使用方式

1. 新建 GitHub 仓库，例如 `water-map`。
2. 上传本文件夹内全部文件。
3. 进入仓库 `Settings > Pages`。
4. Source 选择 `Deploy from a branch`。
5. Branch 选择 `main`，Folder 选择 `/root`。
6. 保存后等待 GitHub Pages 生成访问链接。

## 本地测试

在本文件夹根目录运行：

```bash
python -m http.server 8000
```

然后打开：

```text
http://localhost:8000
```

## 地图数据

当前代码会在线读取 GeoJSON：

```text
https://geojson.cn/api/china/100000.json
```

如果希望完全离线部署，可以把该 GeoJSON 下载为：

```text
assets/china.json
```

然后把 `js/app.js` 里的：

```javascript
const GEOJSON_URL = "https://geojson.cn/api/china/100000.json";
```

改成：

```javascript
const GEOJSON_URL = "./assets/china.json";
```

## 方案编码

- XtraSafe大胖紫 = 1 = #B7A4F3
- Quell ST风味大师 = 2 = #00B0F0
- Quell ST+MinUp = 3 = #FFFF00
